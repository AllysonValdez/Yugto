# Tetron
A Tetris clone being made using the [Godot Game Engine](https://godotengine.org/).
The commits follow the progress of a tutorial series that I am producing.

[Video Tutorial Playlist](https://www.youtube.com/playlist?list=PLFTE4-k_Qh3tfkbsapJdRBmU0Y8gze_dl)
